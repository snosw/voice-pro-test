var class_frostweep_games_1_1_voice_pro_1_1_recorder =
[
    [ "RefreshMicrophones", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a1096dfa5011bcacdb390e7248ddbdd51", null ],
    [ "SetMicrophone", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#ab41d36f5fe66d2768971f78c23c48ca4", null ],
    [ "StartRecord", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a6db0e77ce8f600bf870c7e6bd3458ae6", null ],
    [ "StopRecord", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a73479c143ae4ae072e8c1118f30b75b6", null ],
    [ "debugEcho", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a6a0fea62689917ffb546f63485156ee5", null ],
    [ "recording", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a69a891d6477d789f8078c285b87b7201", null ],
    [ "RecordEndedEvent", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a5d55c09afdb9c98522b510a36dca12f4", null ],
    [ "RecordFailedEvent", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a06429e395656d4b4a8650ab1b4c5fb1f", null ],
    [ "RecordStartedEvent", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a23244381313617fcc8ba16747a08165d", null ]
];