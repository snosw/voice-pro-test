var class_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n_1_1_parse_error =
[
    [ "ParseError", "class_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n_1_1_parse_error.html#aa357c6a7dc5d45912276d90e44755659", null ],
    [ "Position", "class_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n_1_1_parse_error.html#a389f887e2e0551ffbe2e3fd135919ef3", null ]
];