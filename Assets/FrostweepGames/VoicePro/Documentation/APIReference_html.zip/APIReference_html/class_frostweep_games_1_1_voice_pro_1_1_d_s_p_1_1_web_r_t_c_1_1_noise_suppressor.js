var class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_noise_suppressor =
[
    [ "NoiseSuppressor", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_noise_suppressor.html#aeabb887b440804c2838f0049d509bfa3", null ],
    [ "ProcessFrame", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_noise_suppressor.html#a6970b35ec37d4c7a1d97d1473aadb8ea", null ]
];