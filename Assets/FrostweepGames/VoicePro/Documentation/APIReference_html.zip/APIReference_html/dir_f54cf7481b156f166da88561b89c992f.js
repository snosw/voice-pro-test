var dir_f54cf7481b156f166da88561b89c992f =
[
    [ "GeneralConfig.cs", "_general_config_8cs.html", [
      [ "GeneralConfig", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html", "class_frostweep_games_1_1_voice_pro_1_1_general_config" ]
    ] ],
    [ "SpeakerConfig.cs", "_speaker_config_8cs.html", [
      [ "SpeakerConfig", "class_frostweep_games_1_1_voice_pro_1_1_speaker_config.html", "class_frostweep_games_1_1_voice_pro_1_1_speaker_config" ]
    ] ]
];