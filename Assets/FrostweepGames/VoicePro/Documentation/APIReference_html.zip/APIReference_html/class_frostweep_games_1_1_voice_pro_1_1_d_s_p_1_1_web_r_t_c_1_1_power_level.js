var class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level =
[
    [ "PowerLevel", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level.html#a586fb5fbf2f45c7583fad607cf65aaf6", null ],
    [ "Update", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level.html#a5a39da5263422c8decfb352b6f15963d", null ],
    [ "averagelevel", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level.html#a271b401c096937b17f35f2e008190e5a", null ],
    [ "frcounter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level.html#aea4c108006848885e22b01e4e9661b72", null ],
    [ "minlevel", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level.html#aeb5f01b9f172c46c21f8de0b53ffca83", null ],
    [ "sfrcounter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level.html#a818104a49f6b549a34dba592f33a3153", null ]
];