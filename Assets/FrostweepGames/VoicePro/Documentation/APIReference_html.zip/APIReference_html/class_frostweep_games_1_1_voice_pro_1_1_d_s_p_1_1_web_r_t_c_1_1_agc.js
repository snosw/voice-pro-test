var class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc =
[
    [ "AgcMode", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html#ab8e2950f2be2c94c9b9eb7095ebac3cd", [
      [ "AgcModeUnchanged", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html#ab8e2950f2be2c94c9b9eb7095ebac3cda00d9885c1bb4626af7d0be9084f505f0", null ],
      [ "AgcModeAdaptiveAnalog", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html#ab8e2950f2be2c94c9b9eb7095ebac3cda96adb676f34c8a86871f312cf7c9cb04", null ],
      [ "AgcModeAdaptiveDigital", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html#ab8e2950f2be2c94c9b9eb7095ebac3cdaad8352f080caa902d59dcd29c6d13c6c", null ],
      [ "AgcModeFixedDigital", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html#ab8e2950f2be2c94c9b9eb7095ebac3cdaf3e149a7705f8c3498532c7513bc39f4", null ]
    ] ],
    [ "Agc", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html#a048016a0c48ceda954f39f96d63e0e44", null ],
    [ "WebRtcAgc_AddFarend", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html#a2972b8262817c811166fc9faca494345", null ],
    [ "WebRtcAgc_Process", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html#abdbfffdfcfd601290b85ad0daa4aaa32", null ],
    [ "WebRtcAgc_VirtualMic", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html#a194b200732d9f31b3df14f9e2f8569c4", null ]
];