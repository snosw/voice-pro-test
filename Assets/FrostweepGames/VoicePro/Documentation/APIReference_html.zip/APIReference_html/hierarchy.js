var hierarchy =
[
    [ "FrostweepGames.VoicePro.AdminTools", "class_frostweep_games_1_1_voice_pro_1_1_admin_tools.html", null ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.AecConfig", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html", null ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.AecCore", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_core.html", null ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.AecPc", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_pc.html", null ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.Agc", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html", null ],
    [ "FrostweepGames.VoicePro.AudioConstants", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html", null ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.Complex", "struct_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_complex.html", null ],
    [ "FrostweepGames.VoicePro.Compressor", "class_frostweep_games_1_1_voice_pro_1_1_compressor.html", null ],
    [ "FrostweepGames.VoicePro.Constants", "class_frostweep_games_1_1_voice_pro_1_1_constants.html", null ],
    [ "DefineProcessing", null, [
      [ "FrostweepGames.VoicePro.DefineProcessing", "class_frostweep_games_1_1_voice_pro_1_1_define_processing.html", null ]
    ] ],
    [ "FrostweepGames.VoicePro.DSP.DspHelper", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_dsp_helper.html", null ],
    [ "FrostweepGames.VoicePro.DSP.EchoCancelFilterLogger", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter_logger.html", null ],
    [ "FrostweepGames.VoicePro.EchoCancellation", "class_frostweep_games_1_1_voice_pro_1_1_echo_cancellation.html", null ],
    [ "EditorWindow", null, [
      [ "FrostweepGames.VoicePro.WelcomeDialog", "class_frostweep_games_1_1_voice_pro_1_1_welcome_dialog.html", null ]
    ] ],
    [ "Exception", null, [
      [ "FrostweepGames.Plugins.SimpleJSON.ParseError", "class_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n_1_1_parse_error.html", null ]
    ] ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.FFT", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_f_f_t.html", null ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.HighPassFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_high_pass_filter.html", null ],
    [ "FrostweepGames.VoicePro.DSP.IAudioFilter", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_filter.html", [
      [ "FrostweepGames.VoicePro.DSP.IAudioTwoWayFilter", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_two_way_filter.html", [
        [ "FrostweepGames.VoicePro.DSP.EchoCancelFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html", [
          [ "FrostweepGames.VoicePro.DSP.WebRTC.WebRtcFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_web_rtc_filter.html", null ]
        ] ],
        [ "FrostweepGames.VoicePro.DSP.NullAudioFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_null_audio_filter.html", null ]
      ] ],
      [ "FrostweepGames.VoicePro.DSP.ResampleFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter.html", null ]
    ] ],
    [ "FrostweepGames.VoicePro.DSP.IAudioInplaceFilter", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_inplace_filter.html", null ],
    [ "IEquatable", null, [
      [ "FrostweepGames.VoicePro.AudioFormat", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html", null ]
    ] ],
    [ "FrostweepGames.VoicePro.INetworkActor", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html", null ],
    [ "FrostweepGames.VoicePro.INetworkProvider", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html", null ],
    [ "FrostweepGames.VoicePro.Jpeg.JaggedArrayHelper", "class_frostweep_games_1_1_voice_pro_1_1_jpeg_1_1_jagged_array_helper.html", null ],
    [ "FrostweepGames.Plugins.SimpleJSON.JObject", "class_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n_1_1_j_object.html", null ],
    [ "FrostweepGames.Plugins.SimpleJSON.JSONDecoder", "class_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n_1_1_j_s_o_n_decoder.html", null ],
    [ "FrostweepGames.Plugins.SimpleJSON.JSONEncoder", "class_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n_1_1_j_s_o_n_encoder.html", null ],
    [ "FrostweepGames.Plugins.SimpleJSON.JSONStreamEncoder", "class_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n_1_1_j_s_o_n_stream_encoder.html", null ],
    [ "MonoBehaviour", null, [
      [ "FrostweepGames.VoicePro.Listener", "class_frostweep_games_1_1_voice_pro_1_1_listener.html", null ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "FrostweepGames.VoicePro.NetworkProviders.Mirror.VoiceNetworkManager", "class_frostweep_games_1_1_voice_pro_1_1_network_providers_1_1_mirror_1_1_voice_network_manager.html", null ],
      [ "FrostweepGames.VoicePro.NetworkProviders.PUN.PhotonConnector", "class_frostweep_games_1_1_voice_pro_1_1_network_providers_1_1_p_u_n_1_1_photon_connector.html", null ],
      [ "FrostweepGames.VoicePro.NetworkProviders.PUN.PhotonLobby", "class_frostweep_games_1_1_voice_pro_1_1_network_providers_1_1_p_u_n_1_1_photon_lobby.html", null ],
      [ "FrostweepGames.VoicePro.Recorder", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html", null ]
    ] ],
    [ "FrostweepGames.VoicePro.NetworkActorInfo", "class_frostweep_games_1_1_voice_pro_1_1_network_actor_info.html", null ],
    [ "FrostweepGames.VoicePro.NetworkRouter.NetworkCommand", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_command.html", null ],
    [ "FrostweepGames.VoicePro.NetworkRouter.NetworkParameters", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_parameters.html", null ],
    [ "FrostweepGames.VoicePro.NetworkRouter", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html", null ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.NoiseSuppressor", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_noise_suppressor.html", null ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.PowerLevel", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level.html", null ],
    [ "FrostweepGames.VoicePro.DSP.ResampleFilterLogger", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html", null ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.RingBuffer", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_ring_buffer.html", null ],
    [ "ScriptableObject", null, [
      [ "FrostweepGames.VoicePro.GeneralConfig", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html", null ]
    ] ],
    [ "FrostweepGames.VoicePro.Speaker", "class_frostweep_games_1_1_voice_pro_1_1_speaker.html", null ],
    [ "FrostweepGames.VoicePro.SpeakerConfig", "class_frostweep_games_1_1_voice_pro_1_1_speaker_config.html", null ],
    [ "FrostweepGames.VoicePro.DSP.WebRTC.Stats", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html", null ]
];