var interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor =
[
    [ "Id", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html#a02e09cdda1e2656dbe4c37e40ee591ff", null ],
    [ "Info", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html#a5c544f7c392a971f9e03bcb7762fb2bf", null ],
    [ "IsAdmin", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html#afe15ca160fc0947672f6320c3db70575", null ],
    [ "Name", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html#a5f59f22cf75a9fe49da155b2583d45e8", null ]
];