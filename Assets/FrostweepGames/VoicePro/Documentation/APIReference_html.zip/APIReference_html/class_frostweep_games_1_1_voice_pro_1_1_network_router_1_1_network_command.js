var class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_command =
[
    [ "Command", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_command.html#a07db92e877ab6506dd904fcf2e241210", [
      [ "Unknown", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_command.html#a07db92e877ab6506dd904fcf2e241210a88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "MuteUser", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_command.html#a07db92e877ab6506dd904fcf2e241210acc067d07286685dc6944ad11fce47e89", null ],
      [ "UnmuteUser", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_command.html#a07db92e877ab6506dd904fcf2e241210af1ca8f6262b62722c0bb58b86be8dd5e", null ]
    ] ],
    [ "NetworkCommand", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_command.html#add234340749ad43a65a338eb45dfed66", null ],
    [ "command", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_command.html#a64d01d82a6298a309f82340092d09f74", null ],
    [ "data", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_command.html#a143f0cf67a1c1817b7cba44cc1e59b89", null ]
];