var class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_web_rtc_filter =
[
    [ "WebRtcFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_web_rtc_filter.html#a2df6dcb861f62bcc9e10899df3e2ac28", null ],
    [ "PerformEchoCancellation", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_web_rtc_filter.html#aad38d7f0620a3b08a45328258a1e4a13", null ]
];