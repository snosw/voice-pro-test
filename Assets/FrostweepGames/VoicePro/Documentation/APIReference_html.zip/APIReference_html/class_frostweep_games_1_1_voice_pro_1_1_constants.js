var class_frostweep_games_1_1_voice_pro_1_1_constants =
[
    [ "Channels", "class_frostweep_games_1_1_voice_pro_1_1_constants.html#a386e5b496280f2c2014918e844827ccd", null ],
    [ "ChunkSize", "class_frostweep_games_1_1_voice_pro_1_1_constants.html#a3262a82807213b29dd92ffe21d1ca4ef", null ],
    [ "ChunkTime", "class_frostweep_games_1_1_voice_pro_1_1_constants.html#a8d82148a9620a91e4a293a06ab36674d", null ],
    [ "RecordingTime", "class_frostweep_games_1_1_voice_pro_1_1_constants.html#a3c61153852ba999de383e3f03df71521", null ],
    [ "SampleRate", "class_frostweep_games_1_1_voice_pro_1_1_constants.html#a9e3421217d2a724bb97500f45f19cdd6", null ]
];