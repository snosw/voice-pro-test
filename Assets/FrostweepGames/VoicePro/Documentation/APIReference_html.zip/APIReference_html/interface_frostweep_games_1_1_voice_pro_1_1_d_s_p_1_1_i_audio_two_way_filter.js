var interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_two_way_filter =
[
    [ "RegisterFramePlayed", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_two_way_filter.html#accb3f7d904e929965566b4287b29a47f", null ]
];