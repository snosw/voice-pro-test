var searchData=
[
  ['boolean_696',['Boolean',['../namespace_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n.html#aa30b097027c7dfcecf56078577400e4aa27226c864bac7454a8504f8edb15d95b',1,'FrostweepGames::Plugins::SimpleJSON']]]
];
