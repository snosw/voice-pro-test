var searchData=
[
  ['widebandsamplespersecond_682',['WidebandSamplesPerSecond',['../class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#ac0de662e853d314a63e35c4c13fdf23c',1,'FrostweepGames::VoicePro::AudioConstants']]]
];
