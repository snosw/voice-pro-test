var searchData=
[
  ['wrap_690',['Wrap',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_ring_buffer.html#a8f93ef2fbe25bdc46f651fcd27c7d497',1,'FrostweepGames::VoicePro::DSP::WebRTC::RingBuffer']]]
];
