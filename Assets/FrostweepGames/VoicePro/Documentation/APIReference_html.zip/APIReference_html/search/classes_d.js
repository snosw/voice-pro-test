var searchData=
[
  ['speaker_423',['Speaker',['../class_frostweep_games_1_1_voice_pro_1_1_speaker.html',1,'FrostweepGames::VoicePro']]],
  ['speakerconfig_424',['SpeakerConfig',['../class_frostweep_games_1_1_voice_pro_1_1_speaker_config.html',1,'FrostweepGames::VoicePro']]],
  ['stats_425',['Stats',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html',1,'FrostweepGames::VoicePro::DSP::WebRTC']]]
];
