var searchData=
[
  ['logger_632',['logger',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#a4c38d49caade3ba086ab2c6d94d515b7',1,'FrostweepGames.VoicePro.DSP.EchoCancelFilter.logger()'],['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter.html#a00e5a71592473ee4b34c877b30e65233',1,'FrostweepGames.VoicePro.DSP.ResampleFilter.logger()']]]
];
