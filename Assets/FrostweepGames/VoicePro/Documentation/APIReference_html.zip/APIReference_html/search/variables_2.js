var searchData=
[
  ['channels_602',['Channels',['../class_frostweep_games_1_1_voice_pro_1_1_constants.html#a386e5b496280f2c2014918e844827ccd',1,'FrostweepGames.VoicePro.Constants.Channels()'],['../class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a74914274a4e57f360cde8f647d10a59b',1,'FrostweepGames.VoicePro.AudioConstants.Channels()'],['../class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#af0abb865ddbedb02971808e83ceb489e',1,'FrostweepGames.VoicePro.AudioFormat.Channels()']]],
  ['chunksize_603',['ChunkSize',['../class_frostweep_games_1_1_voice_pro_1_1_constants.html#a3262a82807213b29dd92ffe21d1ca4ef',1,'FrostweepGames::VoicePro::Constants']]],
  ['chunktime_604',['ChunkTime',['../class_frostweep_games_1_1_voice_pro_1_1_constants.html#a8d82148a9620a91e4a293a06ab36674d',1,'FrostweepGames::VoicePro::Constants']]],
  ['cn_5fscale_5fhband_605',['cn_scale_Hband',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_core.html#a2d4bd8535f47d37e82dbafcf4e9032d1',1,'FrostweepGames::VoicePro::DSP::WebRTC::AecCore']]],
  ['command_606',['command',['../class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_command.html#a64d01d82a6298a309f82340092d09f74',1,'FrostweepGames::VoicePro::NetworkRouter::NetworkCommand']]],
  ['compressingoftrasferdataenabled_607',['compressingOfTrasferDataEnabled',['../class_frostweep_games_1_1_voice_pro_1_1_general_config.html#ae62a2cb51539ef6f085f641300033493',1,'FrostweepGames::VoicePro::GeneralConfig']]],
  ['counter_608',['counter',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#a2f2af88af3c4ea3986ffcd233c1899e4',1,'FrostweepGames::VoicePro::DSP::WebRTC::Stats']]]
];
