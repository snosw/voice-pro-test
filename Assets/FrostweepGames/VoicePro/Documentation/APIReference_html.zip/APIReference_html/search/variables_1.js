var searchData=
[
  ['bitspersample_598',['BitsPerSample',['../class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a96cec6dddbd2352a67782bd24f6c697d',1,'FrostweepGames.VoicePro.AudioConstants.BitsPerSample()'],['../class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#aad6550885d1ffb4ded2df75347977747',1,'FrostweepGames.VoicePro.AudioFormat.BitsPerSample()']]],
  ['bufsizesamp_599',['BufSizeSamp',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a17c01686b1aefc4573b6da93f855552e',1,'FrostweepGames::VoicePro::DSP::WebRTC::AecConfig']]],
  ['bytesperframe_600',['BytesPerFrame',['../class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a1c7b361710c4c574fcd349b344531f26',1,'FrostweepGames::VoicePro::AudioFormat']]],
  ['bytespersample_601',['BytesPerSample',['../class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a611afd9dd9b76ffab4946ae686eb7cf8',1,'FrostweepGames.VoicePro.AudioConstants.BytesPerSample()'],['../class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a9d3aca4426d72f10da265bdaef9ed6e5',1,'FrostweepGames.VoicePro.AudioFormat.BytesPerSample()']]]
];
