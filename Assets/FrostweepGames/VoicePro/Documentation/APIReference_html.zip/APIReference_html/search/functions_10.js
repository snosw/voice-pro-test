var searchData=
[
  ['update_583',['Update',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level.html#a5a39da5263422c8decfb352b6f15963d',1,'FrostweepGames::VoicePro::DSP::WebRTC::PowerLevel']]]
];
