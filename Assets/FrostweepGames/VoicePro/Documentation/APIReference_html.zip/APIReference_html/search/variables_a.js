var searchData=
[
  ['name_642',['Name',['../class_frostweep_games_1_1_voice_pro_1_1_speaker.html#a10c8d6c75af0db399357981ef7f50cf2',1,'FrostweepGames.VoicePro.Speaker.Name()'],['../class_frostweep_games_1_1_voice_pro_1_1_network_actor_info.html#a8f256d440f6d3e1e1dc1439d16eace99',1,'FrostweepGames.VoicePro.NetworkActorInfo.name()']]],
  ['narrowbandsamplespersecond_643',['NarrowbandSamplesPerSecond',['../class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a0e65725c317745a1090c5923659969f4',1,'FrostweepGames::VoicePro::AudioConstants']]],
  ['networkprovider_644',['networkProvider',['../class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a0361f91f9327856b4130075233be6416',1,'FrostweepGames::VoicePro::GeneralConfig']]],
  ['nlpmode_645',['NlpMode',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a22553a95fdd39a874f8ed818b00d6e19',1,'FrostweepGames::VoicePro::DSP::WebRTC::AecConfig']]],
  ['numpartitions_646',['NumPartitions',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a763ed3f45cfe3b43f38b6cc02e5d6c4b',1,'FrostweepGames::VoicePro::DSP::WebRTC::AecConfig']]]
];
