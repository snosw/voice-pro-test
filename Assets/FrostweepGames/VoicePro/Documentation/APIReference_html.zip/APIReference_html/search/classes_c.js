var searchData=
[
  ['recorder_419',['Recorder',['../class_frostweep_games_1_1_voice_pro_1_1_recorder.html',1,'FrostweepGames::VoicePro']]],
  ['resamplefilter_420',['ResampleFilter',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter.html',1,'FrostweepGames::VoicePro::DSP']]],
  ['resamplefilterlogger_421',['ResampleFilterLogger',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html',1,'FrostweepGames::VoicePro::DSP']]],
  ['ringbuffer_422',['RingBuffer',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_ring_buffer.html',1,'FrostweepGames::VoicePro::DSP::WebRTC']]]
];
