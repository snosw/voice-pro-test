var searchData=
[
  ['average_596',['average',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#a6b46293000e8d98dbb4b49ffac36285b',1,'FrostweepGames::VoicePro::DSP::WebRTC::Stats']]],
  ['averagelevel_597',['averagelevel',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level.html#a271b401c096937b17f35f2e008190e5a',1,'FrostweepGames::VoicePro::DSP::WebRTC::PowerLevel']]]
];
