var searchData=
[
  ['voicedetectionenabled_680',['voiceDetectionEnabled',['../class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a3900ce7ea75003b326599892a99d9936',1,'FrostweepGames::VoicePro::GeneralConfig']]],
  ['voicedetectionthreshold_681',['voiceDetectionThreshold',['../class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a643b58706e0a6c970f6fda5addace29a',1,'FrostweepGames::VoicePro::GeneralConfig']]]
];
