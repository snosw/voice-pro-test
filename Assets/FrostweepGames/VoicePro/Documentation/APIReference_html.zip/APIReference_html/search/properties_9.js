var searchData=
[
  ['name_760',['Name',['../interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html#a5f59f22cf75a9fe49da155b2583d45e8',1,'FrostweepGames::VoicePro::INetworkActor']]],
  ['networkactor_761',['NetworkActor',['../interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#ae0a1c44fe90d7de2b76902cc9ce35b19',1,'FrostweepGames.VoicePro.INetworkProvider.NetworkActor()'],['../class_frostweep_games_1_1_voice_pro_1_1_speaker.html#a8445d166dfac50acec15d8a1872e0dd6',1,'FrostweepGames.VoicePro.Speaker.NetworkActor()']]]
];
