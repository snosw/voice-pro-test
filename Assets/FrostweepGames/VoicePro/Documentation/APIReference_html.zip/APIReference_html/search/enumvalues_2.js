var searchData=
[
  ['diffwrap_697',['DiffWrap',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_ring_buffer.html#a8f93ef2fbe25bdc46f651fcd27c7d497a16af03428fa90b44beae53660504cbfd',1,'FrostweepGames::VoicePro::DSP::WebRTC::RingBuffer']]],
  ['double_698',['Double',['../namespace_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n.html#aedc29b74e168b1ddec581649a17332efad909d38d705ce75386dd86e611a82f5b',1,'FrostweepGames::Plugins::SimpleJSON']]]
];
