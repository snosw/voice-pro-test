var searchData=
[
  ['kind_755',['Kind',['../class_frostweep_games_1_1_plugins_1_1_simple_j_s_o_n_1_1_j_object.html#a08f412ef042aa6502015fdf1cba9cf04',1,'FrostweepGames::Plugins::SimpleJSON::JObject']]]
];
