var searchData=
[
  ['defineprocessing_390',['DefineProcessing',['../class_frostweep_games_1_1_voice_pro_1_1_define_processing.html',1,'FrostweepGames::VoicePro']]],
  ['dsphelper_391',['DspHelper',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_dsp_helper.html',1,'FrostweepGames::VoicePro::DSP']]]
];
