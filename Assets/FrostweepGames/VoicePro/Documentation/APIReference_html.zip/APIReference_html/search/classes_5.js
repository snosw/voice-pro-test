var searchData=
[
  ['generalconfig_396',['GeneralConfig',['../class_frostweep_games_1_1_voice_pro_1_1_general_config.html',1,'FrostweepGames::VoicePro']]]
];
