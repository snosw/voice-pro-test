var searchData=
[
  ['max_633',['max',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#a0f8c6a513c85ab6ff91754b2baa4d85f',1,'FrostweepGames::VoicePro::DSP::WebRTC::Stats']]],
  ['maxinactivetime_634',['maxInactiveTime',['../class_frostweep_games_1_1_voice_pro_1_1_speaker_config.html#a34db21d6ce501b3676871d1972de2eee',1,'FrostweepGames::VoicePro::SpeakerConfig']]],
  ['maxqueuedaudioframes_635',['MaxQueuedAudioFrames',['../class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a77ef547b7c33f95ad03c40dfba15403c',1,'FrostweepGames::VoicePro::AudioFormat']]],
  ['metricsmode_636',['metricsMode',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_core.html#ab89b1d3568fabb0d04212865d6b1f87f',1,'FrostweepGames.VoicePro.DSP.WebRTC.AecCore.metricsMode()'],['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a5c4d0fe89121517b025da8f646e011ee',1,'FrostweepGames.VoicePro.DSP.WebRTC.AecConfig.MetricsMode()']]],
  ['millisecondsperframe_637',['MillisecondsPerFrame',['../class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a02b5221b8fb278505263975fd54f40c0',1,'FrostweepGames.VoicePro.AudioConstants.MillisecondsPerFrame()'],['../class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#ac21a33372432b7363711e410d05a4672',1,'FrostweepGames.VoicePro.AudioFormat.MillisecondsPerFrame()']]],
  ['min_638',['min',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#a18a312395ee3a04c5920cd8a25959926',1,'FrostweepGames::VoicePro::DSP::WebRTC::Stats']]],
  ['minlevel_639',['minlevel',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_power_level.html#aeb5f01b9f172c46c21f8de0b53ffca83',1,'FrostweepGames::VoicePro::DSP::WebRTC::PowerLevel']]],
  ['minoverdrive_640',['minOverDrive',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_core.html#a9a243ed1deb1b1152aec2fa4431fa338',1,'FrostweepGames::VoicePro::DSP::WebRTC::AecCore']]],
  ['mult_641',['mult',['../class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_core.html#af4637759b88e87fd7265c603165b0e8d',1,'FrostweepGames::VoicePro::DSP::WebRTC::AecCore']]]
];
