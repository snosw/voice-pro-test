var dir_b28d31edc64ccbf22af954357286bf3f =
[
    [ "Configs", "dir_f54cf7481b156f166da88561b89c992f.html", "dir_f54cf7481b156f166da88561b89c992f" ],
    [ "Constants.cs", "_constants_8cs.html", [
      [ "Constants", "class_frostweep_games_1_1_voice_pro_1_1_constants.html", "class_frostweep_games_1_1_voice_pro_1_1_constants" ]
    ] ]
];