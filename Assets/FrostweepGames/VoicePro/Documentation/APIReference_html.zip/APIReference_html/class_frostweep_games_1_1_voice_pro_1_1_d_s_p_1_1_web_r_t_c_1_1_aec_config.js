var class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config =
[
    [ "AecConfig", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a5d8d4f30db7fcfc99677c8c4b9ea533e", null ],
    [ "BufSizeSamp", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a17c01686b1aefc4573b6da93f855552e", null ],
    [ "FarBufferLength", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#aaf2612f37f7ca828f30d629a666cc886", null ],
    [ "FilterLength", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#ae67e3c6750444a5a4099d727dcd360cd", null ],
    [ "FilterLength2", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#aa9a4524e4c609104eedf855040ac75c3", null ],
    [ "MetricsMode", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a5c4d0fe89121517b025da8f646e011ee", null ],
    [ "NlpMode", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a22553a95fdd39a874f8ed818b00d6e19", null ],
    [ "NumPartitions", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a763ed3f45cfe3b43f38b6cc02e5d6c4b", null ],
    [ "PART_LEN", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#afb8b0fefee1a6c4f04f4cc54749fa3d1", null ],
    [ "PART_LEN1", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a371e2c49a6f012a9076882e18e483f74", null ],
    [ "PART_LEN2", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#aee5be7bc65d3ad40faf663b1018e4721", null ],
    [ "PREF_BAND_SIZE", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#a94c5e7bd485bc9832994ba8173f0ad63", null ],
    [ "SamplesPerFrame", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#ad4b4132f3961487c222480a4f2c8088a", null ],
    [ "SamplesPerSecond", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#ab95758c8586a05ab13c2d70834fe6770", null ],
    [ "SkewMode", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_config.html#aa73b11acbccc2fe13a20211024e3b567", null ]
];