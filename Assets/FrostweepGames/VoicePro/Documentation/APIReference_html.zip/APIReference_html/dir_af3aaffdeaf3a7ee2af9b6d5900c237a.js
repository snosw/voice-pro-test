var dir_af3aaffdeaf3a7ee2af9b6d5900c237a =
[
    [ "EchoCancellation", "dir_c87a65555de6d3401889b5f49b509abf.html", "dir_c87a65555de6d3401889b5f49b509abf" ],
    [ "JSON", "dir_18e5c3509ded09c37346c1adcb861c59.html", "dir_18e5c3509ded09c37346c1adcb861c59" ],
    [ "AdminTools.cs", "_admin_tools_8cs.html", [
      [ "AdminTools", "class_frostweep_games_1_1_voice_pro_1_1_admin_tools.html", "class_frostweep_games_1_1_voice_pro_1_1_admin_tools" ]
    ] ],
    [ "Compressor.cs", "_compressor_8cs.html", [
      [ "Compressor", "class_frostweep_games_1_1_voice_pro_1_1_compressor.html", "class_frostweep_games_1_1_voice_pro_1_1_compressor" ]
    ] ]
];