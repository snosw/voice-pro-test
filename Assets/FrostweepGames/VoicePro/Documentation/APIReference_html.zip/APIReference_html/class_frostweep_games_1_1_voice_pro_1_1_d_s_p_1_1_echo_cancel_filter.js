var class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter =
[
    [ "EchoCancelFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#affad872ce28432351af52f084ede47d1", null ],
    [ "PerformEchoCancellation", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#a7cbd3824ab63c2de028c2a2d65b955de", null ],
    [ "Read", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#afd8d0d4e0d34c125218d3d05a1d1d95c", null ],
    [ "RegisterFramePlayed", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#adf07856f26122e0575ec64103066e2ab", null ],
    [ "Write", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#a5c23a5ff8abc4077d819a34bec8ea7f2", null ],
    [ "logger", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#a4c38d49caade3ba086ab2c6d94d515b7", null ],
    [ "playedAudioFormat", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#a12b23df4233779941234a1328cc462fd", null ],
    [ "recordedAudioFormat", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#ab3f113e0b3f98f3edbb2869d11902376", null ],
    [ "FilterLength", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#a65214baba4622b5c5bcf9e1a08d6c59b", null ],
    [ "InstanceName", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#a967d84994b4bcb921f871d1b4fe08988", null ],
    [ "QueueSize", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#ab649f3202ed1cd021a522671081cf3ba", null ],
    [ "SamplesPerFrame", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#a7a380c3fb26bba9cedf7b039841b2616", null ],
    [ "SamplesPerSecond", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#a2946863d99ea864c063f62d449b3f6b1", null ],
    [ "SystemLatency", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html#a840c686b8c1f488dfa544ddf2739a0b2", null ]
];