var class_frostweep_games_1_1_voice_pro_1_1_echo_cancellation =
[
    [ "EchoCancellation", "class_frostweep_games_1_1_voice_pro_1_1_echo_cancellation.html#a5a631167b63c127c303aaeebf0967f13", null ],
    [ "GetProcessEchoCancellationFrame", "class_frostweep_games_1_1_voice_pro_1_1_echo_cancellation.html#a9841ce36bc36578526a7a470cc7e6d76", null ],
    [ "RegisterFramePlayed", "class_frostweep_games_1_1_voice_pro_1_1_echo_cancellation.html#ad7efd0137e289317ae6474c7c746a344", null ],
    [ "RegisterFrameRecorded", "class_frostweep_games_1_1_voice_pro_1_1_echo_cancellation.html#a8eb7c2aa3e5a82d4a2f040c8dbb22c65", null ],
    [ "Instance", "class_frostweep_games_1_1_voice_pro_1_1_echo_cancellation.html#a9b65f10688a35cec3dcc4a84490db957", null ]
];