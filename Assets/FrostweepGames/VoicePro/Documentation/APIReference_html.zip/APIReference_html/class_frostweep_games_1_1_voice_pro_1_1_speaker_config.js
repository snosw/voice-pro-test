var class_frostweep_games_1_1_voice_pro_1_1_speaker_config =
[
    [ "maxInactiveTime", "class_frostweep_games_1_1_voice_pro_1_1_speaker_config.html#a34db21d6ce501b3676871d1972de2eee", null ],
    [ "outputAudioMixerGroup", "class_frostweep_games_1_1_voice_pro_1_1_speaker_config.html#aac3eb74fb148d51d6aad8381c12c55a2", null ],
    [ "spatialBlend", "class_frostweep_games_1_1_voice_pro_1_1_speaker_config.html#a6bf66b50c70d0396d229d314668186c6", null ]
];