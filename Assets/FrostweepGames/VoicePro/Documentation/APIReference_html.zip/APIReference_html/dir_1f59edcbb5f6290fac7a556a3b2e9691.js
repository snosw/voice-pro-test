var dir_1f59edcbb5f6290fac7a556a3b2e9691 =
[
    [ "Editor", "dir_6529edd08fc2df298938044a232cbad7.html", "dir_6529edd08fc2df298938044a232cbad7" ],
    [ "Networking", "dir_17790824fb8be72908c1fa38cb1cf0c1.html", "dir_17790824fb8be72908c1fa38cb1cf0c1" ],
    [ "Settings", "dir_b28d31edc64ccbf22af954357286bf3f.html", "dir_b28d31edc64ccbf22af954357286bf3f" ],
    [ "Tools", "dir_af3aaffdeaf3a7ee2af9b6d5900c237a.html", "dir_af3aaffdeaf3a7ee2af9b6d5900c237a" ],
    [ "Listener.cs", "_listener_8cs.html", [
      [ "Listener", "class_frostweep_games_1_1_voice_pro_1_1_listener.html", "class_frostweep_games_1_1_voice_pro_1_1_listener" ]
    ] ],
    [ "Recorder.cs", "_recorder_8cs.html", [
      [ "Recorder", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html", "class_frostweep_games_1_1_voice_pro_1_1_recorder" ]
    ] ],
    [ "Speaker.cs", "_speaker_8cs.html", [
      [ "Speaker", "class_frostweep_games_1_1_voice_pro_1_1_speaker.html", "class_frostweep_games_1_1_voice_pro_1_1_speaker" ]
    ] ]
];