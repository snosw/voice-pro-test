var class_frostweep_games_1_1_voice_pro_1_1_audio_constants =
[
    [ "BitsPerSample", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a96cec6dddbd2352a67782bd24f6c697d", null ],
    [ "BytesPerSample", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a611afd9dd9b76ffab4946ae686eb7cf8", null ],
    [ "Channels", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a74914274a4e57f360cde8f647d10a59b", null ],
    [ "FrameBufferSizeInShorts", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a82768ac454ca4e26764bd2cce4227d74", null ],
    [ "MillisecondsPerFrame", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a02b5221b8fb278505263975fd54f40c0", null ],
    [ "NarrowbandSamplesPerSecond", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a0e65725c317745a1090c5923659969f4", null ],
    [ "SpeexComplexity", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a5e250d2b5b008816d500e3c8c3e7a16b", null ],
    [ "SpeexMode", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a89cdfc60c68b5b02da15feaed6e4a868", null ],
    [ "SpeexQuality", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a9ff2e81ed80bc9095b4008a95d350930", null ],
    [ "UltrawidebandSamplesPerSecond", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#a82d609e38bd65c3516d3f781bd6fca65", null ],
    [ "WidebandSamplesPerSecond", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html#ac0de662e853d314a63e35c4c13fdf23c", null ]
];