var class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_dsp_helper =
[
    [ "GetAverage", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_dsp_helper.html#a2c40a6cacadf64319a20573dfb87e823", null ],
    [ "GetRootMeanSquare", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_dsp_helper.html#aed23f6324f73f18ba53eb37a298d48b2", null ],
    [ "GetStandardDeviation", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_dsp_helper.html#aaa13b14eace8e07b8fb43ee281200d38", null ],
    [ "GetStandardDeviation", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_dsp_helper.html#a9e9a51fd62a2bbf816cce7ed085b1907", null ]
];