var interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_filter =
[
    [ "Read", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_filter.html#a0c29e81856f4bf0878dabda0c6d6b549", null ],
    [ "Write", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_filter.html#a4b4dc7651163aacf14f261f7389dab80", null ],
    [ "InstanceName", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_filter.html#a22cd10843d8dd9129222c13a345790dd", null ]
];