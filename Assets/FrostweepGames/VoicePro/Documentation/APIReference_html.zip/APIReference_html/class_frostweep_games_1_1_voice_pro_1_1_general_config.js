var class_frostweep_games_1_1_voice_pro_1_1_general_config =
[
    [ "NetworkProvider", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#af8ac2f65c62c2fa661ece0d317514cdf", [
      [ "Unknown", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#af8ac2f65c62c2fa661ece0d317514cdfa88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "PUN2_NETWORK_PROVIDER", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#af8ac2f65c62c2fa661ece0d317514cdfa8ebff1592bf9bb3791a871a932063498", null ],
      [ "MIRROR_NETWORK_PROVIDER", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#af8ac2f65c62c2fa661ece0d317514cdfa4eb1af67b643a9140b544024d92525e4", null ]
    ] ],
    [ "compressingOfTrasferDataEnabled", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#ae62a2cb51539ef6f085f641300033493", null ],
    [ "echoCancellation", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a33758fd5fc78c689e954107da8628d77", null ],
    [ "echoCancellationEnableAec", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#ad057d659b43a3f0e4b578fe7e2fbcec3", null ],
    [ "echoCancellationEnableAgc", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a6bf22195510ccde59e8c7ae3ee6275bb", null ],
    [ "echoCancellationEnableDenoise", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a81f511dd859cf43b0ec9db7a7f378599", null ],
    [ "networkProvider", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a0361f91f9327856b4130075233be6416", null ],
    [ "reliableTransmission", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a9bc6b1d980c66d8893d58bbb58f1f41f", null ],
    [ "showWelcomeDialogAtStartup", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#ac5012ba4d07028981f8822073605ae68", null ],
    [ "speakerConfig", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a10941e6370b9e2602d52063e9f427c9d", null ],
    [ "useInternalImplementationOfNetwork", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#ab4654005b0fbd5a6b9c3e4f03e09cacf", null ],
    [ "voiceDetectionEnabled", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a3900ce7ea75003b326599892a99d9936", null ],
    [ "voiceDetectionThreshold", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#a643b58706e0a6c970f6fda5addace29a", null ],
    [ "Config", "class_frostweep_games_1_1_voice_pro_1_1_general_config.html#ae11d66a6337ca39367fb385a9e5f27a5", null ]
];