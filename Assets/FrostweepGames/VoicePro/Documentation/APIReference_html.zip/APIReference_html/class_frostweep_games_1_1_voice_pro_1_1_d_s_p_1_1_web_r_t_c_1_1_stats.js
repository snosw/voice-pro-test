var class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats =
[
    [ "Stats", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#a9aba07a90a7ed3fd4650c0ffefede7db", null ],
    [ "average", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#a6b46293000e8d98dbb4b49ffac36285b", null ],
    [ "counter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#a2f2af88af3c4ea3986ffcd233c1899e4", null ],
    [ "hicounter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#ac1958eec18107c4ceb614b1309410b9d", null ],
    [ "himean", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#ab7cd50fdb38eb43923eefa03cd9b75cc", null ],
    [ "hisum", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#a1de118e8cfcc9c72f0656b79ee8528bf", null ],
    [ "instant", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#ab82261f939fd08ec589877abbc78ed48", null ],
    [ "max", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#a0f8c6a513c85ab6ff91754b2baa4d85f", null ],
    [ "min", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#a18a312395ee3a04c5920cd8a25959926", null ],
    [ "sum", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_stats.html#afd68d87f7f3d6f72f769b36a9b80db6e", null ]
];