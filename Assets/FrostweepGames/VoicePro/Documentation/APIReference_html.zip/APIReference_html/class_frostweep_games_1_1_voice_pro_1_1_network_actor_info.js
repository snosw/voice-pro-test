var class_frostweep_games_1_1_voice_pro_1_1_network_actor_info =
[
    [ "id", "class_frostweep_games_1_1_voice_pro_1_1_network_actor_info.html#a184f28e8be18efa5ec19a4e0186fc636", null ],
    [ "name", "class_frostweep_games_1_1_voice_pro_1_1_network_actor_info.html#a8f256d440f6d3e1e1dc1439d16eace99", null ]
];