var dir_d2bee0b9e0ba3d42fe2a699d52382bad =
[
    [ "VoiceNetworkManager.cs", "_voice_network_manager_8cs.html", [
      [ "VoiceNetworkManager", "class_frostweep_games_1_1_voice_pro_1_1_network_providers_1_1_mirror_1_1_voice_network_manager.html", "class_frostweep_games_1_1_voice_pro_1_1_network_providers_1_1_mirror_1_1_voice_network_manager" ]
    ] ]
];