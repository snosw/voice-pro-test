var dir_c87a65555de6d3401889b5f49b509abf =
[
    [ "AecCore.cs", "_aec_core_8cs.html", "_aec_core_8cs" ],
    [ "AecPc.cs", "_aec_pc_8cs.html", [
      [ "AecPc", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_pc.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_aec_pc" ]
    ] ],
    [ "Agc.cs", "_agc_8cs.html", [
      [ "Agc", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_agc" ]
    ] ],
    [ "AudioConstants.cs", "_audio_constants_8cs.html", [
      [ "AudioConstants", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants.html", "class_frostweep_games_1_1_voice_pro_1_1_audio_constants" ]
    ] ],
    [ "AudioFormat.cs", "_audio_format_8cs.html", [
      [ "AudioFormat", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html", "class_frostweep_games_1_1_voice_pro_1_1_audio_format" ]
    ] ],
    [ "DspHelper.cs", "_dsp_helper_8cs.html", [
      [ "DspHelper", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_dsp_helper.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_dsp_helper" ]
    ] ],
    [ "EchoCancelFilter.cs", "_echo_cancel_filter_8cs.html", [
      [ "EchoCancelFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter" ]
    ] ],
    [ "EchoCancelFilterLogger.cs", "_echo_cancel_filter_logger_8cs.html", [
      [ "EchoCancelFilterLogger", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter_logger.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_echo_cancel_filter_logger" ]
    ] ],
    [ "EchoCancellation.cs", "_echo_cancellation_8cs.html", [
      [ "EchoCancellation", "class_frostweep_games_1_1_voice_pro_1_1_echo_cancellation.html", "class_frostweep_games_1_1_voice_pro_1_1_echo_cancellation" ]
    ] ],
    [ "Fft.cs", "_fft_8cs.html", [
      [ "FFT", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_f_f_t.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_f_f_t" ]
    ] ],
    [ "IAudioFilter.cs", "_i_audio_filter_8cs.html", [
      [ "IAudioFilter", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_filter.html", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_filter" ],
      [ "IAudioTwoWayFilter", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_two_way_filter.html", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_two_way_filter" ],
      [ "IAudioInplaceFilter", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_inplace_filter.html", "interface_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_i_audio_inplace_filter" ]
    ] ],
    [ "JaggedArrayHelper.cs", "_jagged_array_helper_8cs.html", [
      [ "JaggedArrayHelper", "class_frostweep_games_1_1_voice_pro_1_1_jpeg_1_1_jagged_array_helper.html", "class_frostweep_games_1_1_voice_pro_1_1_jpeg_1_1_jagged_array_helper" ]
    ] ],
    [ "NoiseSuppressor.cs", "_noise_suppressor_8cs.html", [
      [ "NoiseSuppressor", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_noise_suppressor.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_noise_suppressor" ]
    ] ],
    [ "NullAudioFilter.cs", "_null_audio_filter_8cs.html", [
      [ "NullAudioFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_null_audio_filter.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_null_audio_filter" ]
    ] ],
    [ "ResampleFilter.cs", "_resample_filter_8cs.html", [
      [ "ResampleFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter" ]
    ] ],
    [ "ResampleFilterLogger.cs", "_resample_filter_logger_8cs.html", [
      [ "ResampleFilterLogger", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger" ]
    ] ],
    [ "WebRtcConstants.cs", "_web_rtc_constants_8cs.html", null ],
    [ "WebRtcFilter.cs", "_web_rtc_filter_8cs.html", [
      [ "WebRtcFilter", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_web_rtc_filter.html", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_web_r_t_c_1_1_web_rtc_filter" ]
    ] ],
    [ "WebRtcUtil.cs", "_web_rtc_util_8cs.html", null ]
];