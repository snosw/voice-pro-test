var class_frostweep_games_1_1_voice_pro_1_1_audio_format =
[
    [ "AudioFormat", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a1a884ef1c496194d4583322b88b375da", null ],
    [ "Equals", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a25f0d4682be0380527b097bb834319e4", null ],
    [ "Equals", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#af7b6ff08a16b78d8c1ee4831ec7eaf2f", null ],
    [ "GetHashCode", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a3f559a571dfdd72cc076278323a9f20e", null ],
    [ "operator!=", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#abff14631cc1a93ac07f74db73328f524", null ],
    [ "operator==", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a890a6db422ca50681737b9cf3dea5c82", null ],
    [ "BitsPerSample", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#aad6550885d1ffb4ded2df75347977747", null ],
    [ "BytesPerFrame", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a1c7b361710c4c574fcd349b344531f26", null ],
    [ "BytesPerSample", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a9d3aca4426d72f10da265bdaef9ed6e5", null ],
    [ "Channels", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#af0abb865ddbedb02971808e83ceb489e", null ],
    [ "FramesPerSecond", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a519632bbb60edd72591448798f89a702", null ],
    [ "MaxQueuedAudioFrames", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a77ef547b7c33f95ad03c40dfba15403c", null ],
    [ "MillisecondsPerFrame", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#ac21a33372432b7363711e410d05a4672", null ],
    [ "SamplesPer10Ms", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#acde40788c9e60789ea918fc22d1f7914", null ],
    [ "SamplesPerFrame", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a8eb7482d13ad357e4042b8940582757d", null ],
    [ "SamplesPerSecond", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#a586162ac05d3782ec44bd4e5c9b67fc3", null ],
    [ "Default", "class_frostweep_games_1_1_voice_pro_1_1_audio_format.html#aeeeff6bfb043640255e32edaf7bc818a", null ]
];