var class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger =
[
    [ "LogCorrectionFactorReset", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a14a55cbce637531a063ef9241c627598", null ],
    [ "LogSamplesRetrieved", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#ac5391a0ae46e74e54e2ce75e2b805035", null ],
    [ "LogSampleSubmitted", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a9b0cfd48bec70b3323d1dd5c031b4a94", null ],
    [ "AverageCorrectedLengthRecent", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a3585c9f5ea4892e6c362fdbbe11e94c8", null ],
    [ "AverageCorrectedLengthTotal", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#add47709e78f5cca81c96221e5f8a6724", null ],
    [ "AverageRetrievalTimeRecent", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a12627868763cac9f1bdf513263e61ba8", null ],
    [ "AverageRetrievalTimeTotal", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a26e4f6993d1992bed1950b98cf00093c", null ],
    [ "AverageSamplesLengthRetrievedRecent", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#ae992e44aa0832ed56b9b2ac8a28c15d9", null ],
    [ "AverageSamplesLengthRetrievedTotal", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a40852b2c51ce3d66346b002c5c6d5744", null ],
    [ "AverageScaledLengthRecent", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a2be6919e9b03e8ef8a5f7df25cea62f1", null ],
    [ "AverageScaledLengthTotal", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a0a15f5ae5ee5e3e0471e63970a25492e", null ],
    [ "AverageSubmissionTimeRecent", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a5d166abfb9162b8df57c71702aed9a25", null ],
    [ "AverageSubmissionTimeTotal", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a66afd0061ef6ed34bcfc9db1f396a140", null ],
    [ "InstanceName", "class_frostweep_games_1_1_voice_pro_1_1_d_s_p_1_1_resample_filter_logger.html#a98ae5365b65d94c00ee0baf164b068c6", null ]
];